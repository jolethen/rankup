
local MP = minetest.get_modpath("xp_redo_ranks_ores")

dofile(MP.."/ranks.lua")

print("[OK] XP-Redo ore ranks")
